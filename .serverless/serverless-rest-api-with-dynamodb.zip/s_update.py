import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='rtorralbar',
    application_name='todo-list-serverless',
    app_uid='h135T5bW05DN88Pmhf',
    org_uid='b66f2930-e836-4e8e-b92b-e80f31469ffd',
    deployment_uid='a093e6a7-ad60-4264-a083-9cb59e062a1a',
    service_name='serverless-rest-api-with-dynamodb',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='3.8.4',
    disable_frameworks_instrumentation=False
)
handler_wrapper_kwargs = {'function_name': 'serverless-rest-api-with-dynamodb-dev-update', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('todos/update.update')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
